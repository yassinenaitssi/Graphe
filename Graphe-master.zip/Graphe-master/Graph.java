package graphe
public interface Graph {
	
	
}