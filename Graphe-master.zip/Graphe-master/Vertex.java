package graphe
public class Vertex {

 public	Vertex vetrex(int x , int y)
	{
		
	}

public int getX()
    {
    	
    }
public int getY()
    {
    	
    }
	
}