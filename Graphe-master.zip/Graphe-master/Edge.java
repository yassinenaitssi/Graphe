package graphe
public abstract class Edge {
	public	Edge edge(Vertex[])
	{

	}
	public abstract Vertex[] getExtremites()
	{
		
	}
}