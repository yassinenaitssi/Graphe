package graphe
public class UndirectedEdge extends Edge {

	public UndirectedEdge(Vertex[] )
	{

	}

	public Vertex[] getExtremites()
	{
		
	}
	
}