package graph
public class DirectedEdge extends Edge {

	public DirectedEdge(Vertex[])
	{

	}
	public Vertex[] getExtremites()
	{

	}
    public Vertex getSource()
    {

    }

    public Vertex getDestination()
    {
    	
    }
}